# Project B MVP

Bangla-first Digital Utility Platform.

## Current MVP
- Free tools
- Bangla AI / career / digital-skills guides
- Mobile-friendly static website
- No paid hosting required

## Deploy
This folder can be uploaded to GitHub Pages or connected to Cloudflare Pages.

## Before public launch
1. Replace "Project B" with the final brand name.
2. Add the first working calculators.
3. Add About / Contact / Privacy pages.
4. Connect Google Search Console and analytics.
5. Publish useful Bangla articles.
